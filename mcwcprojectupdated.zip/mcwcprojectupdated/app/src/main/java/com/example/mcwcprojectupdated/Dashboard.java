package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        SharedPreferences sp=getSharedPreferences("MP",Context.MODE_PRIVATE);
        Toast.makeText(this, sp.getString("User_Email",null),Toast.LENGTH_SHORT).show();


    }
    public void onCreatePoll(View view)
    {
        startActivity(new Intent(this,CreatePoll.class));
    }
    public void onFindPoll(View view)
    {
        startActivity(new Intent(this,FindPoll.class));
    }
}
