package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    Button b1;
    EditText e1,e2,e3,e4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        b1=(Button)findViewById(R.id.Reg_submit);



    }
    public void doReg(View v)
    {
        e1=(EditText)findViewById(R.id.Reg_name);
        e2=(EditText)findViewById(R.id.Reg_email);
        e3=(EditText)findViewById(R.id.Reg_phone);
        e4=(EditText)findViewById(R.id.Reg_pass);
        String s1,s2,s3,s4;
        s1=e1.getText().toString();
        s2=e2.getText().toString();
        s3=e3.getText().toString();
        s4=e4.getText().toString();
        BackgroundTask bt=new BackgroundTask(this, new response() {
            @Override
            public void onProgressFinish(String res, Context c) {
                Toast.makeText(c,"jnd",Toast.LENGTH_LONG).show();
                if(res.equals("register"))
                {
                    startActivity(new Intent(c,Login.class));

                }
            }
        });
        bt.execute("Register",s1,s2,s3,s4);

    }



}
