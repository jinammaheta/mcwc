package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class FindPoll extends AppCompatActivity {
    EditText e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_poll);
    }
    public void onFindPoll(View v)
    {
        e=(EditText)findViewById(R.id.pollid_find);
        BackgroundTask bt=new BackgroundTask(this, new response() {
            @Override
            public void onProgressFinish(String res, Context c) {

                Intent i=new Intent(FindPoll.this, vote.class);
                i.putExtra("s",res);
                startActivity(i);
            }
        });
        bt.execute("findpoll",e.getText().toString());
    }
}
