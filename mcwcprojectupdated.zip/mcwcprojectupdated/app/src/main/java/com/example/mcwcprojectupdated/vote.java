package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class vote extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vote);
        String s=getIntent().getStringExtra("s");
        final String data[]=s.split("@!");
        TextView question=(TextView)findViewById(R.id.Question);
        question.setText(data[3]);
        String options[]=data[4].split("/");
        final RadioButton r[]=new RadioButton[options.length];
        final RadioGroup rg=(RadioGroup)findViewById(R.id.radiogroup_vote);
        for(int i=0;i<options.length;i++)
        {
            r[i]=new RadioButton(this);
            r[i].setText(options[i]);
            r[i].setId((i+1));
            rg.addView(r[i]);
        }

        BackgroundTask bt1 = new BackgroundTask(this, new response() {
            String item="";
            @Override
            public void onProgressFinish(String res, final Context c) {
                final RelativeLayout rl=(RelativeLayout)findViewById(R.id.relativelayout_vote);

                if(res.equals("Voted"))
                {

                    TextView t=new TextView(c);
                    t.setText("Thanks for Voting");
                    RelativeLayout.LayoutParams lp=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
                    lp.addRule(RelativeLayout.BELOW,rg.getId());
                    rl.addView(t,lp);

                }
                else
                {
                    final Button b=new Button(c);
                    b.setText("VOTE");
                    b.setId((1));
                    b.setEnabled(false);
                    RelativeLayout.LayoutParams lp=new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
                    lp.addRule(RelativeLayout.BELOW,rg.getId());
                    rl.addView(b,lp);
                    rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup radioGroup, int i) {
                            item=r[i-1].getText().toString();
                            b.setEnabled(true);
                        }
                    });
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent i=new Intent(c,submitvote.class);
                            i.putExtra("poll_id",data[0]);
                            i.putExtra("choice",item);
                            startActivity(i);
                        }
                    });
                }
            }
        });
        bt1.execute("Vote",data[0],getSharedPreferences("MP",0).getString("User_Email",null).toString());


    }
}
