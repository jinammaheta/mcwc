package com.example.mcwcprojectupdated;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class CreatePollDb extends AsyncTask<String, Void, String> {
    response r1=null;
    String res="";
    Context c;
    CreatePollDb(Context c, response r)
    {
        this.r1=r;
        this.c=c;
    }
    @Override
    protected String doInBackground(String... params) {
        String regurl = "http://192.168.1.102:8080/projectmcwc/createpoll.php";
        try {
            URL url = new URL(regurl);
            HttpURLConnection huc = (HttpURLConnection) url.openConnection();
            huc.setRequestMethod("POST");
            huc.connect();
            String data= URLEncoder.encode("User_Email")+"="+URLEncoder.encode(params[0])+"&"
                    +URLEncoder.encode("pollN")+"="+URLEncoder.encode(params[1])+"&"+
                    URLEncoder.encode("pollQ")+"="+URLEncoder.encode(params[2])+"&"+
                    URLEncoder.encode("options")+"="+URLEncoder.encode(params[3]);
            OutputStream os=huc.getOutputStream();
            BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
            bw.write(data);
            bw.flush();
            bw.close();
            os.close();
            InputStream is = huc.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            res = br.readLine();


        } catch (MalformedURLException e) {
            res = e.getMessage();

        } catch (FileNotFoundException e) {
            res = e.getMessage();
        } catch (NullPointerException e) {
            res ="aaa"+ e.getMessage();
        }
        catch (Exception e)
        {
            res=e.getMessage();
        }

        return res;
    }

    @Override
    protected void onPostExecute(String s) {

        r1.onProgressFinish(res,c);
    }
}
