package com.example.mcwcprojectupdated;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.NetworkOnMainThreadException;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class BackgroundTask extends AsyncTask<String, Void, String> {

    response r1=null;
    String res="";
    Context c;
    BackgroundTask(Context c, response r)
    {
        this.r1=r;
        this.c=c;
    }
    @Override
    protected void onPreExecute()
    {
    }
    @Override
    protected String doInBackground(String... params) {

        if (params[0].equals("Register")) {
            String regurl = "http://192.168.1.102:8080/projectmcwc/register.php";
            try {
                URL url = new URL(regurl);
                HttpURLConnection huc = (HttpURLConnection) url.openConnection();
                huc.setRequestMethod("POST");
                huc.connect();
                String data=URLEncoder.encode("name")+"="+URLEncoder.encode(params[1])+"&"
                        +URLEncoder.encode("email")+"="+URLEncoder.encode(params[2])+"&"+
                        URLEncoder.encode("phone")+"="+URLEncoder.encode(params[3])+"&"+
                        URLEncoder.encode("pass")+"="+URLEncoder.encode(params[4]);
                OutputStream os=huc.getOutputStream();
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
                bw.write(data);
                bw.flush();
                bw.close();
                os.close();
                InputStream is = huc.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                res = br.readLine();


            } catch (MalformedURLException e) {
                res = e.getMessage();

            } catch (FileNotFoundException e) {
                res = e.getMessage();
            } catch (Exception e) {
                res = e.getMessage();
            }


        } else if(params[0].equals("Login")) {
            String regurl = "http://192.168.1.102:8080/projectmcwc/login.php";
            try {
                URL url = new URL(regurl);
                HttpURLConnection huc = (HttpURLConnection) url.openConnection();
                huc.setRequestMethod("POST");
                huc.connect();
                String data=URLEncoder.encode("user_name")+"="+URLEncoder.encode(params[1])+"&"
                        +URLEncoder.encode("password")+"="+URLEncoder.encode(params[2]);
                OutputStream os=huc.getOutputStream();
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
                bw.write(data);
                bw.flush();
                bw.close();
                os.close();
                InputStream is = huc.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                res = br.readLine();
            } catch (MalformedURLException e) {
                res = e.getMessage();

            } catch (FileNotFoundException e) {
                res = e.getMessage();
            } catch (Exception e) {
                res = e.getMessage();
            }
        }
        else if(params[0].equals("findpoll")) {
            String regurl = "http://192.168.1.102:8080/projectmcwc/findpolldata.php";
            res="inside findpoll ";
            try {
                URL url = new URL(regurl);
                HttpURLConnection huc = (HttpURLConnection) url.openConnection();
                huc.setRequestMethod("POST");
                huc.connect();
                String data=URLEncoder.encode("poll_id")+"="+URLEncoder.encode(params[1]);
                OutputStream os=huc.getOutputStream();
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
                bw.write(data);
                bw.flush();
                bw.close();
                os.close();
                InputStream is = huc.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                res = br.readLine();
            } catch (MalformedURLException e) {
                res = e.getMessage();
            } catch (FileNotFoundException e) {
                res = e.getMessage();
            } catch (Exception e) {
                res = e.getMessage();
            }
        }
        else if(params[0].equals("Vote")) {
            String regurl = "http://192.168.1.102:8080/projectmcwc/findvoted.php";
            res="inside voted or not? ";
            try {
                URL url = new URL(regurl);
                HttpURLConnection huc = (HttpURLConnection) url.openConnection();
                huc.setRequestMethod("POST");
                huc.connect();
                String data=URLEncoder.encode("poll_id")+"="+URLEncoder.encode(params[1])
                        +"&" +URLEncoder.encode("email")+"="+URLEncoder.encode(params[2]);;
                OutputStream os=huc.getOutputStream();
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
                bw.write(data);
                bw.flush();
                bw.close();
                os.close();
                InputStream is = huc.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                res = br.readLine();
            } catch (MalformedURLException e) {
                res = e.getMessage();
            } catch (FileNotFoundException e) {
                res = e.getMessage();
            } catch (Exception e) {
                res = e.getMessage();
            }
        }
        else if(params[0].equals("SubmitVote")) {
            String regurl = "http://192.168.1.102:8080/projectmcwc/submitvote.php";
            res="inside voted or not? ";
            try {
                URL url = new URL(regurl);
                HttpURLConnection huc = (HttpURLConnection) url.openConnection();
                huc.setRequestMethod("POST");
                huc.connect();
                String data=URLEncoder.encode("poll_id")+"="+URLEncoder.encode(params[1])
                        +"&"+URLEncoder.encode("voter_id")+"="+URLEncoder.encode(params[2])
                        +"&" +URLEncoder.encode("choice")+"="+URLEncoder.encode(params[3]);;
                OutputStream os=huc.getOutputStream();
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(os));
                bw.write(data);
                bw.flush();
                bw.close();
                os.close();
                InputStream is = huc.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                res = br.readLine();
            } catch (MalformedURLException e) {
                res = e.getMessage();
            } catch (FileNotFoundException e) {
                res = e.getMessage();
            } catch (Exception e) {
                res = e.getMessage();
            }
        }
        return res;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String res) {
        Toast.makeText(c,res ,Toast.LENGTH_LONG).show();
        r1.onProgressFinish(res,c);
        


    }


}
