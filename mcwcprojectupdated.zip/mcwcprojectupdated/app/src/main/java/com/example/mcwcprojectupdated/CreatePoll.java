package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class CreatePoll extends AppCompatActivity {
    EditText e[];
    int n;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_poll);
    }
    public void onAdd(View view)
    {
        EditText e1=(EditText)findViewById(R.id.numofoptions);
        n=Integer.parseInt(e1.getText().toString());
        LinearLayout r1=(LinearLayout)findViewById(R.id.optionslayout);
        e=new EditText[n];
        for(int i=0;i<n;i++)
        {
            e[i]=new EditText(this);
            e[i].setText("option "+(i+1));
            e[i].setId((i+1));
            e[i].setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            r1.addView(e[i]);
        }
        Button b=(Button)findViewById(R.id.btn_submit);
        b.setClickable(true);
    }
    public void onSubmit(View v)
    {
        try {
            EditText e1, e2;
            e1 = (EditText) findViewById(R.id.pollName);
            e2 = (EditText) findViewById(R.id.pollQuestion);
            String s = "";
            for (int i = 0; i < n - 1; i++) {
                s += e[i].getText().toString() + "/";
            }
            s += e[n - 1].getText().toString();
            CreatePollDb cpd = new CreatePollDb(this, new response() {
                @Override
                public void onProgressFinish(String res, Context c) {

                    Toast.makeText(c, res, Toast.LENGTH_SHORT).show();
                    System.out.println(res);

                }
            });
            String user = getSharedPreferences("MP", 0).getString("User_Email", null);
            cpd.execute(user, e1.getText().toString(), e2.getText().toString(), s);
        }
        catch(NullPointerException np)
        {
            Toast.makeText(this,"dff"+np.toString(),Toast.LENGTH_LONG).show();
        }
    }

}
