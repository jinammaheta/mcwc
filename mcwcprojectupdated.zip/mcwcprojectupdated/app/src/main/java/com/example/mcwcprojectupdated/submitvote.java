package com.example.mcwcprojectupdated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

public class submitvote extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submitvote);
        String choice=getIntent().getStringExtra("choice");
        String poll_id=getIntent().getStringExtra("poll_id");
        BackgroundTask bt = new BackgroundTask(this, new response() {
            @Override
            public void onProgressFinish(String res, Context c) {
                Toast.makeText(c,res,Toast.LENGTH_SHORT).show();
                if(res.equals("voted successfully"))
                {

                    startActivity(new Intent(c,FindPoll.class));
                }
            }
        });
        bt.execute("SubmitVote",poll_id, getSharedPreferences("MP",0).getString("User_Email",null).toString(), choice);
    }
}
